Kinetix OS In-Memory Boot Filesystem (tar / ustar)
===================================================
This filesystem contains the initial root directory structure,
system metadata, configuration files, and native ELF applications
loaded directly into RAM during early kernel boot.
Files:
  - /bin/hello-world : Freestanding native ELF64 user application
  - /etc/os-release  : Operating system identity and metadata
  - /etc/motd        : Message of the day banner
  - /README.txt      : Filesystem documentation
===================================================
